const openModalBtn = document.getElementById('openModalBtn');
const loginModal = document.getElementById('loginModal');
const closeModal = document.getElementById('closeModal');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const indexInput = document.getElementById('indexInput');
const passwordInput = document.getElementById('passwordInput');
const eventsList = document.getElementById('eventsList');
const adminPanel = document.getElementById('adminPanel');
const createEventForm = document.getElementById('createEventForm');
const adminMsg = document.getElementById('adminMsg');
const userArea = document.getElementById('userArea');

const API_BASE = '/api';

// modal handlers
openModalBtn?.addEventListener('click', () => {
  loginModal.style.display = 'flex';
});
closeModal?.addEventListener('click', () => {
  loginModal.style.display = 'none';
});
window.addEventListener('click', (e) => {
  if (e.target === loginModal) loginModal.style.display = 'none';
});

// auth helpers
function saveAuth(token, user) {
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
}
function clearAuth() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
}
function getToken() { return localStorage.getItem('token'); }
function getUser() { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } }

function showLoggedInUI() {
  const user = getUser();
  if (!user) {
    userArea.innerHTML = `<button id="openModalBtn" class="btn primary">Open LMS</button>`;
    document.getElementById('openModalBtn').addEventListener('click', () => loginModal.style.display = 'flex');
    adminPanel.style.display = 'none';
    return;
  }

  userArea.innerHTML = `<div style="display:flex;gap:12px;align-items:center">
    <div style="font-weight:600">${user.name} (${user.indexNumber})</div>
    <button id="logoutBtn" class="btn secondary">Logout</button>
  </div>`;
  document.getElementById('logoutBtn').addEventListener('click', () => {
    clearAuth();
    showLoggedInUI();
    renderEvents(); // will fail to fetch events (need login)
  });

  // show admin panel if admin
  if (user.role === 'admin') {
    adminPanel.style.display = 'block';
  } else {
    adminPanel.style.display = 'none';
  }
}

async function renderEvents() {
  const token = getToken();
  if (!token) {
    eventsList.innerHTML = '<div class="event-card">Please login to view events.</div>';
    return;
  }
  try {
    const res = await fetch(`${API_BASE}/events`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.status === 401) {
      eventsList.innerHTML = '<div class="event-card">Session expired or unauthorized. Please login again.</div>';
      return;
    }
    const events = await res.json();
    if (!events.length) {
      eventsList.innerHTML = '<div class="event-card">No upcoming events.</div>';
      return;
    }
    eventsList.innerHTML = events.map(ev => {
      const d = new Date(ev.date);
      return `<div class="event-card">
        <h3>${ev.title}</h3>
        <div class="event-meta">${d.toLocaleString()} · ${ev.venue || ''}</div>
        <p>${ev.description || ''}</p>
      </div>`;
    }).join('');
  } catch (err) {
    console.error(err);
    eventsList.innerHTML = '<div class="event-card">Error loading events.</div>';
  }
}

// login submit
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  loginError.textContent = '';
  const indexNumber = indexInput.value.trim();
  const password = passwordInput.value.trim();
  if (!indexNumber || !password) {
    loginError.textContent = 'Please fill both fields';
    return;
  }
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ indexNumber, password })
    });
    const data = await res.json();
    if (!res.ok) {
      loginError.textContent = data?.msg || 'Login failed';
      return;
    }
    saveAuth(data.token, data.user);
    loginModal.style.display = 'none';
    indexInput.value = ''; passwordInput.value = '';
    showLoggedInUI();
    await renderEvents();
  } catch (err) {
    console.error(err);
    loginError.textContent = 'Network error';
  }
});

// create event (admin)
createEventForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  adminMsg.textContent = '';
  const title = document.getElementById('evTitle').value.trim();
  const date = document.getElementById('evDate').value;
  const venue = document.getElementById('evVenue').value.trim();
  const description = document.getElementById('evDesc').value.trim();
  if (!title || !date) { adminMsg.textContent = 'Please enter title and date'; return; }

  try {
    const res = await fetch(`${API_BASE}/events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getToken()}`
      },
      body: JSON.stringify({ title, description, date, venue })
    });
    const data = await res.json();
    if (!res.ok) {
      adminMsg.textContent = data?.msg || 'Failed to create event';
      return;
    }
    adminMsg.textContent = 'Event created!';
    createEventForm.reset();
    renderEvents();
  } catch (err) {
    console.error(err);
    adminMsg.textContent = 'Network error';
  }
});

// init UI
showLoggedInUI();
renderEvents();
