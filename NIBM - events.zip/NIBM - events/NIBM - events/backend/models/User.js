const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  indexNumber: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  faculty: { type: String },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['student','admin'], default: 'student' }
});

module.exports = mongoose.model('User', UserSchema);
