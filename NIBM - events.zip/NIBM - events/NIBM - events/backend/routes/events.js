const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Event = require('../models/Event');

// GET /api/events
router.get('/', auth, async (req, res) => {
  try {
    const now = new Date();
    const events = await Event.find({ date: { $gte: now } }).sort('date');
    res.json(events);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

// POST /api/events (admin only)
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ msg: 'Admins only' });
    const { title, description, date, venue } = req.body;
    if (!title || !date) return res.status(400).json({ msg: 'Provide title and date' });
    const event = new Event({ title, description, date, venue, createdBy: req.user.id });
    await event.save();
    res.json(event);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
