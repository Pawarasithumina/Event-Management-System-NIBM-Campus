require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Event = require('./models/Event');
const connectDB = require('./config/db');

const students = [
  { indexNumber: 'S1001', name: 'Kavindu Perera', faculty: 'Computing', password: 'pass123' },
  { indexNumber: 'S1002', name: 'Nethmi Fernando', faculty: 'Business', password: 'pass234' },
  { indexNumber: 'S1003', name: 'Shehan Jayasinghe', faculty: 'Computing', password: 'pass345' },
  { indexNumber: 'S1004', name: 'Dinithi Weerasinghe', faculty: 'Engineering', password: 'pass456' },
  { indexNumber: 'S1005', name: 'Malith Silva', faculty: 'Computing', password: 'pass567' },
  { indexNumber: 'S1006', name: 'Hiruni Dissanayake', faculty: 'Design', password: 'pass678' },
  { indexNumber: 'S1007', name: 'Supun Abeysekara', faculty: 'Business', password: 'pass789' },
  { indexNumber: 'S1008', name: 'Sachini Rajapaksha', faculty: 'Computing', password: 'pass890' },
  { indexNumber: 'S1009', name: 'Pasindu Liyanage', faculty: 'Engineering', password: 'pass901' },
  { indexNumber: 'S1010', name: 'Tharushi Gunawardena', faculty: 'Computing', password: 'pass012' },
  // admin
  { indexNumber: process.env.ADMIN_INDEX || 'ADM-0001', name: 'Admin User', faculty: 'Admin', password: 'adminpass', role: 'admin' }
];

(async () => {
  try {
    await connectDB(process.env.MONGO_URI);
    console.log('Connected. Seeding...');

    await User.deleteMany({});
    await Event.deleteMany({});

    for (const s of students) {
      const salt = await bcrypt.genSalt(10);
      const hash = await bcrypt.hash(s.password, salt);
      await new User({
        indexNumber: s.indexNumber,
        name: s.name,
        faculty: s.faculty,
        passwordHash: hash,
        role: s.role || 'student'
      }).save();
      console.log('Seeded:', s.indexNumber);
    }

    // optional: create a sample event by admin
    const admin = await User.findOne({ role: 'admin' });
    if (admin) {
      await new Event({
        title: 'Welcome Orientation',
        description: 'Welcome session for new students.',
        date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        venue: 'Main Auditorium',
        createdBy: admin._id
      }).save();
      console.log('Sample event created.');
    }

    console.log('Seeding complete.');
    process.exit(0);
  } catch (err) {
    console.error('Seeding error:', err);
    process.exit(1);
  }
})();
